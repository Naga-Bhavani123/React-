// Write your code here

import {Component} from 'react'
import './index.css'

class ReviewsCarousel extends Component {
  state = {index: 0}

  Rightarrow = () => {
    const {reviewsList} = this.props
    this.setState(prvState => {
      const value = prvState.index + 1
      if (value >= reviewsList.length) {
        return {index: prvState.index}
      }
      return {index: value}
    })
  }

  leftarrow = () => {
    const {reviewsList} = this.props
    console.log(reviewsList)
    this.setState(prvState => {
      const value = prvState.index - 1
      const len = reviewsList.length
      console.log(len)
      if (value < 0) {
        return {index: 0}
      }
      return {index: value}
    })
  }

  render() {
    const {reviewsList} = this.props
    const {index} = this.state
    const ele = reviewsList[index]

    return (
      <div className="bg">
        <h1 className="mainHeading">Reviews</h1>
        <div className="cart">
          <button
            type="button"
            onClick={this.leftarrow}
            className="button"
            data-testid="leftArrow"
          >
            <img
              src="https://assets.ccbp.in/frontend/react-js/left-arrow-img.png"
              className="arrow"
              alt="left arrow"
            />
          </button>

          <div className="profileCart">
            <img src={ele.imgUrl} className="image" alt={ele.username} />
            <p className="userName">{ele.username}</p>
            <p className="companyName">{ele.companyName}</p>
            <p className="description">{ele.description}</p>
          </div>
          <button
            type="button"
            onClick={this.Rightarrow}
            className="button"
            data-testid="rightArrow"
          >
            <img
              src="https://assets.ccbp.in/frontend/react-js/right-arrow-img.png"
              className="arrow"
              alt="right arrow"
            />
          </button>
        </div>
      </div>
    )
  }
}

export default ReviewsCarousel
