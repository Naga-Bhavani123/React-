// Write your code here

import './index.css'

const AppItem = props => {
  const {Item} = props
  const {appName, imageUrl} = Item

  return (
    <li className="listItem">
      <img src={imageUrl} className="image" alt={appName} />
      <p className="paraImg">{appName}</p>
    </li>
  )
}

export default AppItem
