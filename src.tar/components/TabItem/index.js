// Write your code here

import './index.css'

const TabItem = props => {
  const {Item, func, isActive} = props
  console.log(Item)
  const {tabId, displayText} = Item

  const onclick = () => func(tabId)

  const boder = isActive ? 'FillBorder button' : 'button'

  return (
    <li className="listItemTab">
      <button id={tabId} className={boder} type="button" onClick={onclick}>
        <p className="para">{displayText}</p>
      </button>
    </li>
  )
}

export default TabItem
