import './index.css'

const TabOptions = props => {
  const {Item, fun} = props
  const {id, thumbnailUrl} = Item

  const func = () => fun(id)

  return (
    <li className="li">
      <button onClick={func} type="button" className="optionsButtons">
        <img className="optionLogo" src={thumbnailUrl} alt="thumbnail" />
      </button>
    </li>
  )
}

export default TabOptions
