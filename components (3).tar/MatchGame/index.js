import {Component} from 'react'
import './index.css'
import TabItems from '../TabItems'
import TabOptions from '../TabOptions'

class MatchGame extends Component {
  constructor(props) {
    super(props)

    this.state = {
      seconds: 60,
      score: 0,
      activatedItem: props.tabsList[0].tabId,
      ThumbnailEel: 0,
      isNotSame: false,
    }
  }

  onPlayAgain = () => {
    const {tabsList} = this.props

    this.setState({
      seconds: 60,
      score: 0,
      activatedItem: tabsList[0].tabId,
      ThumbnailEel: 0,
      isNotSame: false,
    })
  }

  getCompletedSection(score) {
    return (
      <div className="bgCompletion">
        <img
          className="tropyLogo"
          src="https://assets.ccbp.in/frontend/react-js/match-game-trophy.png"
          alt="trophy"
        />
        <p className="scoreCompleted">Your Score</p>
        <h1 className="scoreCompleted1">{score}</h1>
        <button
          type="button"
          className="palyAgainButton palyAgainText"
          onClick={this.onPlayAgain}
        >
          <img
            className="resetIcon"
            src="https://assets.ccbp.in/frontend/react-js/match-game-play-again-img.png"
            alt="reset"
          />
          <p>PLAY AGAIN</p>
        </button>
      </div>
    )
  }

  getGameSection(updatedTabItems, tabsList, activatedItem, ThumbnailEel) {
    const {imagesList} = this.props
    const {imageUrl} = imagesList[ThumbnailEel]
    // console.log(disPlayEle)

    return (
      <div className="imageCart">
        <img className="thumbnaiImage" src={imageUrl} alt="match" />
        <ul className="tabsCon">
          {tabsList.map(ele => (
            <TabItems
              Item={ele}
              key={ele.tabId}
              isActive={ele.tabId === activatedItem}
              fun={this.onEachItemClick}
            />
          ))}
        </ul>
        <ul className="ulOptions">
          {updatedTabItems.map(ele => (
            <TabOptions Item={ele} key={ele.id} fun={this.onClickOfItem} />
          ))}
        </ul>
      </div>
    )
  }

  onClickOfItem = id => {
    const {imagesList} = this.props
    this.setState(prvState => {
      const new1 = imagesList[prvState.ThumbnailEel]
      // const value = prvState.ThumbnailEel + 1
      const ID = new1.id
      let returnEle = {isNotSame: true}
      if (id === ID) {
        returnEle = {
          score: prvState.score + 1,
          ThumbnailEel: Math.ceil(Math.random() * imagesList.length),
        }
      }
      return returnEle
    })
  }

  onEachItemClick = id => {
    this.setState({activatedItem: id})
  }

  componentDidMount = () => {
    this.intervalId = setInterval(() => {
      this.setState(prvState => {
        const {seconds} = prvState
        const s = seconds - 1
        return {seconds: s}
      })
    }, 1000)
  }

  render() {
    const {imagesList, tabsList} = this.props
    const {seconds, score, activatedItem, ThumbnailEel, isNotSame} = this.state
    const updatedTabItems = imagesList.filter(
      ele => ele.category === activatedItem,
    )

    if (seconds === 0 || isNotSame) {
      clearInterval(this.intervalId)
    }

    return (
      <div className="bg">
        <ul className="navBar">
          <li>
            <img
              className="navLogo"
              src="https://assets.ccbp.in/frontend/react-js/match-game-website-logo.png"
              alt="website logo"
            />
          </li>

          <li className="navRightCon">
            <p className="scorePara">
              Score: <span className="onlyScore">{score}</span>
            </p>
            <div className="timerCon">
              <img
                className="timerLogo"
                src="https://assets.ccbp.in/frontend/react-js/match-game-timer-img.png"
                alt="timer"
              />
              <p className="timeSeconds">{seconds} Sec</p>
            </div>
          </li>
        </ul>
        <div className="buttonCart">
          {seconds === 0 || isNotSame
            ? this.getCompletedSection(score)
            : this.getGameSection(
                updatedTabItems,
                tabsList,
                activatedItem,
                ThumbnailEel,
              )}
        </div>
      </div>
    )
  }
}
export default MatchGame
