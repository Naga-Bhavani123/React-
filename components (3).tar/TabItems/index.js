import './index.css'

const TabItems = props => {
  const {Item, isActive, fun} = props
  const {tabId, displayText} = Item

  const func = () => fun(tabId)

  const isValue = isActive ? 'buttonTab ButtonItemsTab' : 'buttonTab'

  return (
    <li className="listItemsTab">
      <button className={isValue} onClick={func} type="button">
        {displayText}
      </button>
    </li>
  )
}

export default TabItems
