import {Component} from 'react'
import './index.css'
import {v4} from 'uuid'
import EachPassword from '../EachPassword'

const listColors = [
  'blue',
  'green',
  'orange',
  'grey',
  'yellow',
  'red',
  'hash',
  'voilet',
]

class PasswordManager extends Component {
  state = {
    website: '',
    password: '',
    userName: '',
    listOfItems: [],
    searchq: '',
    isDisplayPassword: false,
  }

  onPassword = event => {
    this.setState({password: event.target.value})
  }

  onUsername = event => {
    this.setState({userName: event.target.value})
  }

  onWebsite = event => {
    this.setState({website: event.target.value})
  }

  addItem = event => {
    event.preventDefault()

    this.setState(prvState => {
      const {website, password, userName, listOfItems} = prvState

      const item = {website, password, username: userName, id: v4()}

      const newListItem = [...listOfItems, item]

      return {website: '', password: '', userName: '', listOfItems: newListItem}
    })
  }

  onDelete = id => {
    this.setState(prvState => {
      const {listOfItems} = prvState

      const newListItems = listOfItems.filter(ele => ele.id !== id)

      return {listOfItems: newListItems}
    })
  }

  onSearch = event => {
    this.setState({searchq: event.target.value})
  }

  onShowPassword = () => {
    this.setState(prvState => ({
      isDisplayPassword: !prvState.isDisplayPassword,
    }))
  }

  render() {
    const {
      website,
      password,
      userName,
      listOfItems,
      searchq,
      isDisplayPassword,
    } = this.state
    let count = 0
    const updatedListItem = listOfItems.filter(ele =>
      ele.website.toLowerCase().includes(searchq.toLowerCase()),
    )

    const updatedListItems = updatedListItem.map(ele => {
      count += 1

      if (count === listColors.length) {
        count = 1
      }

      return {...ele, color: listColors[count - 1]}
    })

    return (
      <div className="bg">
        <div className="innerbg">
          <img
            className="logo"
            src="https://assets.ccbp.in/frontend/react-js/password-manager-logo-img.png"
            alt="app logo"
          />
          <div className="topCart">
            <img
              className="topImage"
              src="https://assets.ccbp.in/frontend/react-js/password-manager-sm-img.png"
              alt="password manager"
            />
            <form className="topCartSearchCart">
              <h1 className="mainHeadingTopCart">Add New Password</h1>
              <div className="inputCon">
                <img
                  className="inputLogo"
                  src="https://assets.ccbp.in/frontend/react-js/password-manager-website-img.png"
                  alt="website"
                />
                <hr />
                <input
                  className="searchInput"
                  type="text"
                  placeholder="Enter Website"
                  onChange={this.onWebsite}
                  value={website}
                />
              </div>
              <div className="inputCon">
                <img
                  className="inputLogo"
                  src="https://assets.ccbp.in/frontend/react-js/password-manager-username-img.png"
                  alt="username"
                />
                <hr />
                <input
                  className="searchInput"
                  type="text"
                  placeholder="Enter Username"
                  onChange={this.onUsername}
                  value={userName}
                />
              </div>
              <div className="inputCon">
                <img
                  className="inputLogo"
                  src="https://assets.ccbp.in/frontend/react-js/password-manager-password-img.png"
                  alt="password"
                />
                <hr />
                <input
                  className="searchInput"
                  type="password"
                  placeholder="Enter Password"
                  onChange={this.onPassword}
                  value={password}
                />
              </div>
              <button
                type="submit"
                className="addButton"
                onClick={this.addItem}
              >
                Add
              </button>
            </form>
          </div>

          <div className="bottomCart">
            <div className="navBar">
              <h1 className="mainHeadingNavBar">
                Your Passwords{' '}
                <p className="displayCount">{updatedListItem.length}</p>
              </h1>
              <div className="inputCon2">
                <img
                  className="inputLogo2"
                  src="https://assets.ccbp.in/frontend/react-js/password-manager-search-img.png"
                  alt="search"
                />
                <hr />
                <input
                  className="searchInput2"
                  type="search"
                  placeholder="Search"
                  onChange={this.onSearch}
                  value={searchq}
                />
              </div>
            </div>
            <hr className="horiLine" />
            <div className="showPasswordCon">
              <input
                type="checkbox"
                className="inputCheckBox"
                id="showPassword"
                onChange={this.onShowPassword}
              />
              <label htmlFor="showPassword" className="labelText">
                Show Passwords
              </label>
            </div>
            <ul className="unList">
              {updatedListItems.map(ele => (
                <EachPassword
                  Item={ele}
                  key={ele.id}
                  fun={this.onDelete}
                  isTrue={isDisplayPassword}
                />
              ))}
            </ul>
            {updatedListItem.length === 0 && (
              <div className="unList2">
                <img
                  src="https://assets.ccbp.in/frontend/react-js/no-passwords-img.png"
                  alt="no passwords"
                  className="bottomImage"
                />
                <p className="mainHeadingNavBar">No Passwords</p>
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }
}

export default PasswordManager
