import './index.css'

const EachPassword = props => {
  const {Item, fun, isTrue} = props
  const {website, password, username, id, color} = Item

  const func = () => fun(id)
  const getPara = () => <p className="webParaItem">{password}</p>

  const getImg = () => (
    <img
      className="starIcons"
      src="https://assets.ccbp.in/frontend/react-js/password-manager-stars-img.png"
      alt="stars"
    />
  )

  return (
    <li className="listItem">
      <p className={`${color} iconPara`}>{website[0].toUpperCase()}</p>
      <div>
        <p className="webParaItem">{website}</p>
        <p className="webParaItem">{username}</p>
        {isTrue ? getPara() : getImg()}
      </div>
      <button
        className="buttonDelete"
        type="button"
        data-testid="delete"
        onClick={func}
      >
        <img
          src="https://assets.ccbp.in/frontend/react-js/password-manager-delete-img.png"
          alt="delete"
          className="deleteIcon"
        />
      </button>
    </li>
  )
}

export default EachPassword
